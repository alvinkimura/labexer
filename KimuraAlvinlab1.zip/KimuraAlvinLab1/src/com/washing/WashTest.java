package com.washing;

public class WashTest {

	public static void main(String[] args) {
		
		WashingMachine wash = new WashingMachine(7.8,
				"Top Load", "Samsung");
		System.out.println("You are using "+ wash.getType() + " "+ wash.getBrand()+" Washing"
				+ " Machine with a capacity of " + wash.getKg() + " kg.");
		
		
		String equivMode = wash.mode();
		String equivIntensity = wash.intensity();
		wash.status(equivMode, equivIntensity);
		

	}

}
