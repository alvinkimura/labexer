package com.washing;
import java.util.Scanner;

public class WashingMachine {

	Scanner scan = new Scanner (System.in);
	
	private double kg;
	private String type;
	private String brand;

	public WashingMachine(double kg, String type,String brand){
		this.kg = kg;
		this.type = type;
		this.brand = brand;
		
	}
	
	public String mode () {
		String currentMode;
		System.out.println("Choose the mode you will"
				+ " be using:");
		System.out.println(" Preset \n Wash\n Rinse\n Spin ");
		currentMode = scan.nextLine();
		System.out.println("You have chosen " + 
		currentMode + ".");
		return currentMode;
	}
	
	public String intensity () {
		String status;
		System.out.println("Choose the intensity: ");
		System.out.println(" Normal \n Heavy Duty \n Energy Saver"
				+ "\n Blanket \n Delicate");
		status = scan.nextLine();
		return status;
	}
	
	public void status ( String mode , String intensity ) {
		
		System.out.println("Undergoing " + mode + " " + intensity + " mode. ");
		System.out.println("Please fill with water and put detergent to start.");
		System.out.println("type PAUSE to stop immediately");
		String stop = scan.nextLine();
		if (stop.equalsIgnoreCase("Pause")) {
			stopWash();
		}
		else
			System.out.println("Invalid input");
		
	}
	
	public void stopWash() {
		System.out.println("Stopping all operations..");
		System.out.println("press 1 to continue");
		int pause;
		do{
		
		System.out.println("press 0 to turn off");
		pause = scan.nextInt();
		
		
		if (pause == 1) {
			System.out.println("Resuming all operations..");
		}
		else if (pause ==0) {
			System.out.println("Turning off....");
		}
		else
			System.out.println("Invalid Input.");
	}while (pause ==1);
		
	}
	
	public double getKg() {
		return this.kg;
	}
	public String getType() {
		return this.type;
	}
	
	public String getBrand() {
		return this.brand;
	}
}
